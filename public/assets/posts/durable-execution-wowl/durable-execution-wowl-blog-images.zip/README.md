# Durable Execution / WOWL blog images

Upload these eight JPG files to:

public/assets/posts/durable-execution-wowl/

Recommended Markdown references:

![Retries are not durable execution](/assets/posts/durable-execution-wowl/01-retries-are-not-durable-execution.jpg)

![The difference is the abstraction layer](/assets/posts/durable-execution-wowl/02-abstraction-layer.jpg)

![Call-level resilience wraps a call](/assets/posts/durable-execution-wowl/03-call-level-resilience.jpg)

![Durable execution wraps a workflow](/assets/posts/durable-execution-wowl/04-durable-execution-workflow.jpg)

![Call failure versus process failure](/assets/posts/durable-execution-wowl/05-call-failure-vs-process-failure.jpg)

![Call-level resilience and process-level durability work together](/assets/posts/durable-execution-wowl/06-you-often-need-both.jpg)

![WOWL: Write Once, Write Last](/assets/posts/durable-execution-wowl/07-wowl-write-once-write-last.jpg)

![Why WOWL matters](/assets/posts/durable-execution-wowl/08-why-wowl-matters.jpg)

Suggested front matter:

Either omit ogImage and let AstroPaper generate it dynamically, or use:

ogImage: /assets/posts/durable-execution-wowl/02-abstraction-layer.jpg

If that triggers Astro's content asset import path issue, remove ogImage.
